# -*- coding: utf-8 -*-
"""
需求清单 Excel 生成器
从结构化需求数据生成专业的 Excel 功能清单文件
"""

from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter
from typing import Dict, List, Any
import json


STYLE_HEADER = Font(bold=True, color='FFFFFF', size=11)
STYLE_HEADER_FILL = PatternFill('solid', fgColor='4472C4')
STYLE_NORMAL = Font(size=10)
STYLE_BORDER = Border(
    left=Side(style='thin'),
    right=Side(style='thin'),
    top=Side(style='thin'),
    bottom=Side(style='thin')
)
STYLE_CENTER = Alignment(horizontal='center', vertical='center', wrap_text=True)
STYLE_LEFT = Alignment(horizontal='left', vertical='center', wrap_text=True)

PRIORITY_COLORS = {
    '高': PatternFill('solid', fgColor='FFCDD2'),
    '中': PatternFill('solid', fgColor='FFF9C4'),
    '低': PatternFill('solid', fgColor='C8E6C9'),
}

STATUS_COLORS = {
    '明确': PatternFill('solid', fgColor='C8E6C9'),
    '待确认': PatternFill('solid', fgColor='FFF9C4'),
    '推断': PatternFill('solid', fgColor='BBDEFB'),
}


def create_overview_sheet(ws, data: Dict[str, Any]):
    ws.title = '需求概览'
    
    headers = ['指标', '数值']
    ws.append(headers)
    for col in range(1, 3):
        cell = ws.cell(row=1, column=col)
        cell.font = STYLE_HEADER
        cell.fill = STYLE_HEADER_FILL
        cell.alignment = STYLE_CENTER
        cell.border = STYLE_BORDER
    
    overview_data = [
        ('需求总数', data.get('total', 0)),
        ('功能需求', data.get('functional', 0)),
        ('非功能需求', data.get('non_functional', 0)),
        ('待确认需求', data.get('pending', 0)),
        ('模块数量', data.get('modules', 0)),
    ]
    
    for row_idx, (label, value) in enumerate(overview_data, start=2):
        ws.cell(row=row_idx, column=1, value=label).border = STYLE_BORDER
        ws.cell(row=row_idx, column=2, value=value).border = STYLE_BORDER
        ws.cell(row=row_idx, column=1).alignment = STYLE_LEFT
        ws.cell(row=row_idx, column=2).alignment = STYLE_CENTER
    
    ws.column_dimensions['A'].width = 20
    ws.column_dimensions['B'].width = 15


def create_functional_sheet(ws, data: List[Dict[str, Any]]):
    ws.title = '功能需求'
    
    headers = ['ID', '模块', '需求描述', '来源', '优先级', '状态', '备注']
    ws.append(headers)
    for col in range(1, 8):
        cell = ws.cell(row=1, column=col)
        cell.font = STYLE_HEADER
        cell.fill = STYLE_HEADER_FILL
        cell.alignment = STYLE_CENTER
        cell.border = STYLE_BORDER
    
    for item in data:
        row_idx = ws.max_row + 1
        ws.cell(row=row_idx, column=1, value=item.get('id', '')).border = STYLE_BORDER
        ws.cell(row=row_idx, column=2, value=item.get('module', '')).border = STYLE_BORDER
        ws.cell(row=row_idx, column=3, value=item.get('description', '')).border = STYLE_BORDER
        ws.cell(row=row_idx, column=4, value=item.get('source', '')).border = STYLE_BORDER
        ws.cell(row=row_idx, column=5, value=item.get('priority', '')).border = STYLE_BORDER
        ws.cell(row=row_idx, column=6, value=item.get('status', '')).border = STYLE_BORDER
        ws.cell(row=row_idx, column=7, value=item.get('remark', '')).border = STYLE_BORDER
        
        priority = item.get('priority', '')
        if priority in PRIORITY_COLORS:
            ws.cell(row=row_idx, column=5).fill = PRIORITY_COLORS[priority]
        
        status = item.get('status', '')
        if status in STATUS_COLORS:
            ws.cell(row=row_idx, column=6).fill = STATUS_COLORS[status]
        
        for col in range(1, 8):
            ws.cell(row=row_idx, column=col).alignment = STYLE_LEFT
    
    ws.column_dimensions['A'].width = 10
    ws.column_dimensions['B'].width = 15
    ws.column_dimensions['C'].width = 40
    ws.column_dimensions['D'].width = 15
    ws.column_dimensions['E'].width = 10
    ws.column_dimensions['F'].width = 10
    ws.column_dimensions['G'].width = 25


def create_non_functional_sheet(ws, data: List[Dict[str, Any]]):
    ws.title = '非功能需求'
    
    headers = ['ID', '需求描述', '类型', '指标要求', '来源']
    ws.append(headers)
    for col in range(1, 6):
        cell = ws.cell(row=1, column=col)
        cell.font = STYLE_HEADER
        cell.fill = STYLE_HEADER_FILL
        cell.alignment = STYLE_CENTER
        cell.border = STYLE_BORDER
    
    for item in data:
        row_idx = ws.max_row + 1
        ws.cell(row=row_idx, column=1, value=item.get('id', '')).border = STYLE_BORDER
        ws.cell(row=row_idx, column=2, value=item.get('description', '')).border = STYLE_BORDER
        ws.cell(row=row_idx, column=3, value=item.get('type', '')).border = STYLE_BORDER
        ws.cell(row=row_idx, column=4, value=item.get('metric', '')).border = STYLE_BORDER
        ws.cell(row=row_idx, column=5, value=item.get('source', '')).border = STYLE_BORDER
        
        for col in range(1, 6):
            ws.cell(row=row_idx, column=col).alignment = STYLE_LEFT
    
    ws.column_dimensions['A'].width = 10
    ws.column_dimensions['B'].width = 35
    ws.column_dimensions['C'].width = 12
    ws.column_dimensions['D'].width = 25
    ws.column_dimensions['E'].width = 15


def create_pending_sheet(ws, data: List[Dict[str, Any]]):
    ws.title = '待确认事项'
    
    headers = ['ID', '问题描述', '相关需求', '建议询问对象']
    ws.append(headers)
    for col in range(1, 5):
        cell = ws.cell(row=1, column=col)
        cell.font = STYLE_HEADER
        cell.fill = STYLE_HEADER_FILL
        cell.alignment = STYLE_CENTER
        cell.border = STYLE_BORDER
    
    for item in data:
        row_idx = ws.max_row + 1
        ws.cell(row=row_idx, column=1, value=item.get('id', '')).border = STYLE_BORDER
        ws.cell(row=row_idx, column=2, value=item.get('question', '')).border = STYLE_BORDER
        ws.cell(row=row_idx, column=3, value=item.get('related', '')).border = STYLE_BORDER
        ws.cell(row=row_idx, column=4, value=item.get('contact', '')).border = STYLE_BORDER
        
        for col in range(1, 5):
            ws.cell(row=row_idx, column=col).alignment = STYLE_LEFT
    
    ws.column_dimensions['A'].width = 10
    ws.column_dimensions['B'].width = 40
    ws.column_dimensions['C'].width = 15
    ws.column_dimensions['D'].width = 18


def create_dependency_sheet(ws, data: List[Dict[str, Any]]):
    ws.title = '需求依赖关系'
    
    headers = ['需求ID', '依赖需求ID', '关系类型', '说明']
    ws.append(headers)
    for col in range(1, 5):
        cell = ws.cell(row=1, column=col)
        cell.font = STYLE_HEADER
        cell.fill = STYLE_HEADER_FILL
        cell.alignment = STYLE_CENTER
        cell.border = STYLE_BORDER
    
    for item in data:
        row_idx = ws.max_row + 1
        ws.cell(row=row_idx, column=1, value=item.get('requirement_id', '')).border = STYLE_BORDER
        ws.cell(row=row_idx, column=2, value=item.get('depends_on', '')).border = STYLE_BORDER
        ws.cell(row=row_idx, column=3, value=item.get('relation_type', '')).border = STYLE_BORDER
        ws.cell(row=row_idx, column=4, value=item.get('description', '')).border = STYLE_BORDER
        
        for col in range(1, 5):
            ws.cell(row=row_idx, column=col).alignment = STYLE_LEFT
    
    ws.column_dimensions['A'].width = 12
    ws.column_dimensions['B'].width = 15
    ws.column_dimensions['C'].width = 12
    ws.column_dimensions['D'].width = 35


def generate_requirement_excel(requirements: Dict[str, Any], output_path: str) -> str:
    wb = Workbook()
    ws_overview = wb.active
    create_overview_sheet(ws_overview, requirements.get('overview', {}))
    
    ws_functional = wb.create_sheet()
    create_functional_sheet(ws_functional, requirements.get('functional', []))
    
    ws_non_functional = wb.create_sheet()
    create_non_functional_sheet(ws_non_functional, requirements.get('non_functional', []))
    
    ws_pending = wb.create_sheet()
    create_pending_sheet(ws_pending, requirements.get('pending', []))
    
    ws_dependency = wb.create_sheet()
    create_dependency_sheet(ws_dependency, requirements.get('dependencies', []))
    
    wb.save(output_path)
    return output_path


def parse_markdown_to_requirements(md_content: str) -> Dict[str, Any]:
    requirements = {
        'overview': {'total': 0, 'functional': 0, 'non_functional': 0, 'pending': 0, 'modules': 0},
        'functional': [],
        'non_functional': [],
        'pending': [],
        'dependencies': []
    }
    
    lines = md_content.split('\n')
    current_section = None
    current_module = None
    
    for line in lines:
        line = line.strip()
        
        if '需求概览' in line or '一、需求概览' in line:
            current_section = 'overview'
        elif '功能需求' in line or '二、功能需求' in line:
            current_section = 'functional'
        elif '非功能需求' in line or '三、非功能需求' in line:
            current_section = 'non_functional'
        elif '待确认事项' in line or '四、待确认事项' in line:
            current_section = 'pending'
        elif '依赖关系' in line or '五、需求依赖' in line:
            current_section = 'dependency'
        elif line.startswith('### 2.'):
            current_module = line.replace('### 2.', '').replace('###', '').strip()
            current_module = current_module.split('.')[-1].strip() if '.' in current_module else current_module
        elif line.startswith('|') and current_section:
            cells = [c.strip() for c in line.split('|')[1:-1]]
            
            if current_section == 'overview' and len(cells) >= 2:
                if '需求总数' in cells[0]:
                    requirements['overview']['total'] = cells[1].replace('个', '')
                elif '功能需求' in cells[0]:
                    requirements['overview']['functional'] = cells[1].replace('个', '')
                elif '非功能需求' in cells[0]:
                    requirements['overview']['non_functional'] = cells[1].replace('个', '')
                elif '待确认' in cells[0]:
                    requirements['overview']['pending'] = cells[1].replace('个', '')
            
            elif current_section == 'functional' and len(cells) >= 6:
                if cells[0] not in ['ID', '----']:
                    requirements['functional'].append({
                        'id': cells[0],
                        'module': current_module or cells[1] if len(cells) > 6 else '',
                        'description': cells[1] if len(cells) <= 6 else cells[2],
                        'source': cells[2] if len(cells) <= 6 else cells[3],
                        'priority': cells[3] if len(cells) <= 6 else cells[4],
                        'status': cells[4] if len(cells) <= 6 else cells[5],
                        'remark': cells[5] if len(cells) <= 6 else cells[6] if len(cells) > 6 else ''
                    })
            
            elif current_section == 'non_functional' and len(cells) >= 4:
                if cells[0] not in ['ID', '----']:
                    requirements['non_functional'].append({
                        'id': cells[0],
                        'description': cells[1],
                        'type': cells[2],
                        'metric': cells[3] if len(cells) > 3 else '',
                        'source': cells[4] if len(cells) > 4 else ''
                    })
            
            elif current_section == 'pending' and len(cells) >= 3:
                if cells[0] not in ['ID', '----']:
                    requirements['pending'].append({
                        'id': cells[0],
                        'question': cells[1],
                        'related': cells[2],
                        'contact': cells[3] if len(cells) > 3 else ''
                    })
    
    modules = set(item.get('module', '') for item in requirements['functional'] if item.get('module'))
    requirements['overview']['modules'] = len(modules)
    
    return requirements


if __name__ == '__main__':
    import sys
    
    if len(sys.argv) < 3:
        print("Usage: python generate_excel.py <input_markdown_file> <output_excel_file>")
        sys.exit(1)
    
    input_file = sys.argv[1]
    output_file = sys.argv[2]
    
    with open(input_file, 'r', encoding='utf-8') as f:
        md_content = f.read()
    
    requirements = parse_markdown_to_requirements(md_content)
    result = generate_requirement_excel(requirements, output_file)
    print(f"Excel file generated: {result}")
